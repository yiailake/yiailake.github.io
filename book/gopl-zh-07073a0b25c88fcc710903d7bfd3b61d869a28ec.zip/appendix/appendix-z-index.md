# 索引

<!-- 索引有三列，每列宽度40个字符
+------------------------------------- + ------------------------------------- + ------------
-->

### P367

```
TODO
```

### P368

```
TODO
```

### P369

```
TODO
```

### P390

```
TODO
```

### P391

```
TODO
```

### P392

```
TODO
```

### P393

```
TODO
```

### P394

```
TODO
```

### P395

```
TODO
```

### P396

```
TODO
```

### P397

```
TODO
```

### P398

```
TODO
```

### P399

```
TODO
```


### P400

<!-- 索引有三列，每列宽度40个字符
+------------------------------------- + ------------------------------------- + ------------
-->

```
  standard 2, 27, 52, 66, 67, 69, 97   variables, shared 257
unicodepackage 71                      variable-size stack 124
unicode.IsDigit function 71            variadic function 142, 172
unicode.IsLetter function 71           vector, bit 165
unicode.IsLower function 71            vendoring 293
unicode.IsSpace function 93            visibility 28, 29, 41, 168, 297
unicode.IsUpper function 71            visit function 122
unicode/utf8package 69
unidirectional channel type 230, 231   wait example 130
union, discriminated 211, 213, 214     WaitForServer function 130
universe block 46                      walkDir function 247
Unix domain socket 219                 web
unmarshaling JSON 110                    crawler 119
unnamed struct type 163                  crawler, concurrent 239
unnamed variable 34, 88                  framework 193
unreachable statement 120              while loop 6
unsafe package 354                     white-box test 311
unsafe.AlignOf function 355            Wilkes, Maurice 301
unsafe.Offsetof function 355           Wirth, Niklaus xiii
unsafe.Pointer conversion 356          word example 303, 305, 308
unsafe.Pointer type 356                word example, test of 303
unsafe.Pointer zero value 356          workspace organization 291
unsafe.Sizeof function 354             writer lock 266
unsigned integer 52, 54                writing effective tests 316, 317
untyped constant types 78
unused parameter 120                   xkcd JSON interface 113
URL 123                                XML decoding 213
URL escape 111                         XML (Extensible Markup Language)
url.QueryEscape function 111               107
url.URLtype 193                        (*xml.Decoder).Token method
url values example 160                     213
UTF-8 66, 67, 98                       xmlselect example 215
UTF-8 encodings, table of 67
utf8.DecodeRuneInString function       zero length slice 87
    69                                 zero value
utf8.RuneCountInString function          array 82
    69                                   boolean 30
utf8.UTFMaxvalue 98                      channel 225, 246
                                         func tion 132
value                                    interface 182
  addressable   32                       map 95
  call by 83, 120, 158                   named result 120, 127
  func tion  132                         number 5, 30
  interface   181                        pointer 32
  method 164                             reflect.Value 332
  utf8.UTFMax 98                         slice 74, 87
var declaration 5, 30                    string 5, 7, 30
variable                                 struct 102
  confinement 261                        unsafe.Pointer 356
  heap 36
  http.DefaultClient 253
  io.Discard 18
  io.EOF 132
  lifetime 35, 46, 135
  local 29, 141
  os.Args 4
  stack 36
  unnamed 34, 88
variables, escaping 36
```
